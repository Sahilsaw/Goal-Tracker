"use client"

import React from "react"

import { Flame, Zap, Star, Crown, Shield, Swords, Target, Trophy } from "lucide-react"
import { cn } from "@/lib/utils"

interface Achievement {
  id: string
  title: string
  description: string
  icon: React.ReactNode
  unlocked: boolean
  progress?: number
  maxProgress?: number
}

interface AchievementsProps {
  totalXp: number
  streak: number
  bestStreak: number
  totalQuests: number
}

export function Achievements({ totalXp, streak, bestStreak, totalQuests }: AchievementsProps) {
  const achievements: Achievement[] = [
    {
      id: "first-quest",
      title: "First Step",
      description: "Complete your first quest",
      icon: <Star className="h-6 w-6" />,
      unlocked: totalQuests >= 1,
      progress: Math.min(totalQuests, 1),
      maxProgress: 1,
    },
    {
      id: "streak-3",
      title: "Burning Spirit",
      description: "Achieve a 3-day streak",
      icon: <Flame className="h-6 w-6" />,
      unlocked: bestStreak >= 3,
      progress: Math.min(bestStreak, 3),
      maxProgress: 3,
    },
    {
      id: "streak-7",
      title: "Week Warrior",
      description: "Achieve a 7-day streak",
      icon: <Shield className="h-6 w-6" />,
      unlocked: bestStreak >= 7,
      progress: Math.min(bestStreak, 7),
      maxProgress: 7,
    },
    {
      id: "xp-100",
      title: "XP Hunter",
      description: "Earn 100 XP total",
      icon: <Zap className="h-6 w-6" />,
      unlocked: totalXp >= 100,
      progress: Math.min(totalXp, 100),
      maxProgress: 100,
    },
    {
      id: "xp-500",
      title: "Power Surge",
      description: "Earn 500 XP total",
      icon: <Swords className="h-6 w-6" />,
      unlocked: totalXp >= 500,
      progress: Math.min(totalXp, 500),
      maxProgress: 500,
    },
    {
      id: "quests-10",
      title: "Quest Master",
      description: "Complete 10 quests",
      icon: <Target className="h-6 w-6" />,
      unlocked: totalQuests >= 10,
      progress: Math.min(totalQuests, 10),
      maxProgress: 10,
    },
    {
      id: "streak-30",
      title: "Legend",
      description: "Achieve a 30-day streak",
      icon: <Crown className="h-6 w-6" />,
      unlocked: bestStreak >= 30,
      progress: Math.min(bestStreak, 30),
      maxProgress: 30,
    },
    {
      id: "xp-1000",
      title: "Grand Master",
      description: "Earn 1000 XP total",
      icon: <Trophy className="h-6 w-6" />,
      unlocked: totalXp >= 1000,
      progress: Math.min(totalXp, 1000),
      maxProgress: 1000,
    },
  ]

  const unlockedCount = achievements.filter((a) => a.unlocked).length

  return (
    <div className="relative overflow-hidden rounded-2xl border-2 border-gold/30 bg-card">
      {/* Decorative corners */}
      <div className="absolute top-0 left-0 h-4 w-4 border-t-2 border-l-2 border-gold" />
      <div className="absolute top-0 right-0 h-4 w-4 border-t-2 border-r-2 border-gold" />
      <div className="absolute bottom-0 left-0 h-4 w-4 border-b-2 border-l-2 border-gold" />
      <div className="absolute right-0 bottom-0 h-4 w-4 border-r-2 border-b-2 border-gold" />

      {/* Header */}
      <div className="flex items-center justify-between border-b border-border bg-gold/10 p-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gold/20 text-gold">
            <Trophy className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-bold text-foreground">Achievements</h3>
            <p className="text-xs text-muted-foreground">Unlock rewards for your progress</p>
          </div>
        </div>
        <div className="flex items-center gap-1 rounded-full bg-gold/20 px-3 py-1 text-sm font-bold text-gold">
          {unlockedCount}/{achievements.length}
        </div>
      </div>

      {/* Achievement Grid */}
      <div className="grid grid-cols-2 gap-3 p-4 md:grid-cols-4">
        {achievements.map((achievement) => (
          <div
            key={achievement.id}
            className={cn(
              "group relative flex flex-col items-center rounded-xl border p-3 text-center transition-all",
              achievement.unlocked
                ? "border-gold/50 bg-gold/10 shadow-lg shadow-gold/10"
                : "border-border bg-secondary/30 opacity-60"
            )}
          >
            <div
              className={cn(
                "mb-2 flex h-12 w-12 items-center justify-center rounded-full",
                achievement.unlocked
                  ? "bg-gold/20 text-gold"
                  : "bg-muted text-muted-foreground"
              )}
            >
              {achievement.icon}
            </div>
            <h4 className={cn("text-xs font-bold", achievement.unlocked ? "text-gold" : "text-muted-foreground")}>
              {achievement.title}
            </h4>
            <p className="mt-1 text-[10px] text-muted-foreground leading-tight">{achievement.description}</p>

            {/* Progress bar for locked achievements */}
            {!achievement.unlocked && achievement.progress !== undefined && achievement.maxProgress !== undefined && (
              <div className="mt-2 h-1 w-full overflow-hidden rounded-full bg-muted">
                <div
                  className="h-full rounded-full bg-gold/50"
                  style={{ width: `${(achievement.progress / achievement.maxProgress) * 100}%` }}
                />
              </div>
            )}

            {/* Unlocked indicator */}
            {achievement.unlocked && (
              <div className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-gold text-[10px] font-bold text-background">
                <Star className="h-3 w-3 fill-current" />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
