"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Flame, Zap, Star, Trophy } from "lucide-react"

interface PlayerCardProps {
  level: number
  xp: number
  maxXp: number
  streak: number
  bestStreak: number
  totalXp: number
}

export function PlayerCard({ level, xp, maxXp, streak, bestStreak, totalXp }: PlayerCardProps) {
  const [animatedXp, setAnimatedXp] = useState(0)
  const xpPercentage = (xp / maxXp) * 100

  useEffect(() => {
    const timer = setTimeout(() => setAnimatedXp(xpPercentage), 100)
    return () => clearTimeout(timer)
  }, [xpPercentage])

  return (
    <div className="relative overflow-hidden rounded-2xl border-2 border-primary/30 bg-card p-4 md:p-6">
      {/* Anime-style decorative corners */}
      <div className="absolute top-0 left-0 h-4 w-4 border-t-2 border-l-2 border-primary" />
      <div className="absolute top-0 right-0 h-4 w-4 border-t-2 border-r-2 border-primary" />
      <div className="absolute bottom-0 left-0 h-4 w-4 border-b-2 border-l-2 border-primary" />
      <div className="absolute right-0 bottom-0 h-4 w-4 border-r-2 border-b-2 border-primary" />

      <div className="flex flex-col gap-4 md:flex-row md:items-center md:gap-6">
        {/* Avatar Section */}
        <div className="relative mx-auto md:mx-0">
          <div className="relative h-24 w-24 overflow-hidden rounded-full border-3 border-accent shadow-lg shadow-accent/20 md:h-32 md:w-32">
            <Image
              src="/mascot.jpg"
              alt="Player Avatar"
              fill
              className="object-cover"
            />
          </div>
          {/* Level Badge */}
          <div className="absolute -right-2 -bottom-2 flex h-10 w-10 items-center justify-center rounded-full border-2 border-accent bg-card font-bold text-accent shadow-lg md:h-12 md:w-12">
            <span className="text-sm md:text-base">Lv.{level}</span>
          </div>
        </div>

        {/* Stats Section */}
        <div className="flex-1 space-y-4">
          {/* Player Title */}
          <div className="text-center md:text-left">
            <h2 className="text-xl font-bold text-foreground md:text-2xl">Code Warrior</h2>
            <p className="text-sm text-muted-foreground">Rank: Apprentice Developer</p>
          </div>

          {/* XP Bar */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs md:text-sm">
              <span className="flex items-center gap-1 text-xp-bar">
                <Zap className="h-4 w-4" />
                EXP
              </span>
              <span className="text-muted-foreground">{xp} / {maxXp}</span>
            </div>
            <div className="relative h-4 overflow-hidden rounded-full bg-secondary md:h-5">
              <div
                className="absolute inset-y-0 left-0 rounded-full bg-xp-bar transition-all duration-1000 ease-out"
                style={{ width: `${animatedXp}%` }}
              />
              {/* Shine effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent" />
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-2 md:gap-4">
            <div className="flex flex-col items-center rounded-xl border border-streak-flame/30 bg-secondary/50 p-2 md:p-3">
              <Flame className="h-5 w-5 text-streak-flame md:h-6 md:w-6" />
              <span className="mt-1 text-lg font-bold text-streak-flame md:text-xl">{streak}</span>
              <span className="text-[10px] text-muted-foreground md:text-xs">Streak</span>
            </div>
            <div className="flex flex-col items-center rounded-xl border border-gold/30 bg-secondary/50 p-2 md:p-3">
              <Trophy className="h-5 w-5 text-gold md:h-6 md:w-6" />
              <span className="mt-1 text-lg font-bold text-gold md:text-xl">{bestStreak}</span>
              <span className="text-[10px] text-muted-foreground md:text-xs">Best</span>
            </div>
            <div className="flex flex-col items-center rounded-xl border border-primary/30 bg-secondary/50 p-2 md:p-3">
              <Star className="h-5 w-5 text-primary md:h-6 md:w-6" />
              <span className="mt-1 text-lg font-bold text-primary md:text-xl">{totalXp}</span>
              <span className="text-[10px] text-muted-foreground md:text-xs">Total XP</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
