"use client"

import React from "react"

import { useState } from "react"
import { Check, Plus, Trash2, Sparkles } from "lucide-react"
import { cn } from "@/lib/utils"

export interface Quest {
  id: string
  title: string
  completed: boolean
  xpReward: number
}

interface QuestCardProps {
  title: string
  icon: React.ReactNode
  quests: Quest[]
  onAddQuest: (title: string) => void
  onToggleQuest: (id: string) => void
  onDeleteQuest: (id: string) => void
  color: "video" | "dsa" | "dev"
}

const colorMap = {
  video: {
    border: "border-primary/40",
    bg: "bg-primary/10",
    text: "text-primary",
    glow: "shadow-primary/20",
    checkbox: "border-primary bg-primary",
  },
  dsa: {
    border: "border-xp-bar/40",
    bg: "bg-xp-bar/10",
    text: "text-xp-bar",
    glow: "shadow-xp-bar/20",
    checkbox: "border-xp-bar bg-xp-bar",
  },
  dev: {
    border: "border-accent/40",
    bg: "bg-accent/10",
    text: "text-accent",
    glow: "shadow-accent/20",
    checkbox: "border-accent bg-accent",
  },
}

export function QuestCard({ title, icon, quests, onAddQuest, onToggleQuest, onDeleteQuest, color }: QuestCardProps) {
  const [newQuestTitle, setNewQuestTitle] = useState("")
  const [isAdding, setIsAdding] = useState(false)
  const completedCount = quests.filter((q) => q.completed).length
  const totalXp = quests.reduce((acc, q) => (q.completed ? acc + q.xpReward : acc), 0)
  const colors = colorMap[color]

  const handleAddQuest = () => {
    if (newQuestTitle.trim()) {
      onAddQuest(newQuestTitle.trim())
      setNewQuestTitle("")
      setIsAdding(false)
    }
  }

  return (
    <div className={cn("relative overflow-hidden rounded-2xl border-2 bg-card", colors.border)}>
      {/* Header */}
      <div className={cn("flex items-center justify-between border-b p-4", colors.border, colors.bg)}>
        <div className="flex items-center gap-3">
          <div className={cn("flex h-10 w-10 items-center justify-center rounded-xl", colors.bg, colors.text)}>
            {icon}
          </div>
          <div>
            <h3 className="font-bold text-foreground">{title}</h3>
            <p className="text-xs text-muted-foreground">
              +{totalXp} XP earned today
            </p>
          </div>
        </div>
        <div className={cn("flex items-center gap-1 rounded-full px-3 py-1 text-sm font-bold", colors.bg, colors.text)}>
          <Sparkles className="h-4 w-4" />
          {completedCount}/{quests.length}
        </div>
      </div>

      {/* Quest List */}
      <div className="max-h-64 space-y-2 overflow-y-auto p-4">
        {quests.length === 0 ? (
          <div className="py-8 text-center">
            <p className="text-muted-foreground">No quests yet!</p>
            <p className="text-sm text-muted-foreground/70">Add your first quest below</p>
          </div>
        ) : (
          quests.map((quest) => (
            <div
              key={quest.id}
              className={cn(
                "group flex items-center gap-3 rounded-xl border p-3 transition-all",
                quest.completed
                  ? "border-border/50 bg-secondary/30"
                  : "border-border bg-secondary/50 hover:border-primary/30"
              )}
            >
              <button
                type="button"
                onClick={() => onToggleQuest(quest.id)}
                className={cn(
                  "flex h-6 w-6 shrink-0 items-center justify-center rounded-md border-2 transition-all",
                  quest.completed ? colors.checkbox : "border-muted-foreground/50 bg-transparent hover:border-primary"
                )}
              >
                {quest.completed && <Check className="h-4 w-4 text-primary-foreground" />}
              </button>
              <div className="flex-1 min-w-0">
                <p className={cn("truncate text-sm font-medium", quest.completed && "text-muted-foreground line-through")}>
                  {quest.title}
                </p>
                <p className={cn("text-xs", colors.text)}>+{quest.xpReward} XP</p>
              </div>
              <button
                type="button"
                onClick={() => onDeleteQuest(quest.id)}
                className="opacity-0 transition-opacity group-hover:opacity-100"
              >
                <Trash2 className="h-4 w-4 text-destructive hover:text-destructive/80" />
              </button>
            </div>
          ))
        )}
      </div>

      {/* Add Quest Section */}
      <div className="border-t border-border p-4">
        {isAdding ? (
          <div className="flex gap-2">
            <input
              type="text"
              value={newQuestTitle}
              onChange={(e) => setNewQuestTitle(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddQuest()}
              placeholder="Enter quest name..."
              className="flex-1 rounded-xl border border-border bg-input px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
              autoFocus
            />
            <button
              type="button"
              onClick={handleAddQuest}
              className={cn("rounded-xl px-4 py-2 font-medium text-primary-foreground transition-colors", colors.checkbox.replace("border-", "bg-"))}
            >
              Add
            </button>
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="rounded-xl border border-border px-4 py-2 text-sm text-muted-foreground hover:bg-secondary"
            >
              Cancel
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setIsAdding(true)}
            className={cn(
              "flex w-full items-center justify-center gap-2 rounded-xl border-2 border-dashed py-3 text-sm font-medium transition-all hover:border-solid",
              colors.border,
              colors.text
            )}
          >
            <Plus className="h-4 w-4" />
            Add Quest
          </button>
        )}
      </div>
    </div>
  )
}
