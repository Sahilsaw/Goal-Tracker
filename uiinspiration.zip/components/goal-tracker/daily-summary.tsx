"use client"

import { Sparkles, CheckCircle2, Clock, Target } from "lucide-react"
import { cn } from "@/lib/utils"

interface DailySummaryProps {
  date: Date
  completedQuests: number
  totalQuests: number
  xpEarned: number
}

export function DailySummary({ date, completedQuests, totalQuests, xpEarned }: DailySummaryProps) {
  const percentage = totalQuests > 0 ? Math.round((completedQuests / totalQuests) * 100) : 0
  const isComplete = completedQuests > 0 && completedQuests === totalQuests

  const formatDate = (d: Date) => {
    const options: Intl.DateTimeFormatOptions = {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    }
    return d.toLocaleDateString("en-US", options)
  }

  const isToday = () => {
    const today = new Date()
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    )
  }

  return (
    <div className={cn(
      "relative overflow-hidden rounded-2xl border-2 bg-card p-4",
      isComplete ? "border-xp-bar/50" : "border-border"
    )}>
      {/* Success glow effect */}
      {isComplete && (
        <div className="absolute inset-0 bg-xp-bar/5" />
      )}

      {/* Decorative corners */}
      <div className={cn("absolute top-0 left-0 h-4 w-4 border-t-2 border-l-2", isComplete ? "border-xp-bar" : "border-muted-foreground/30")} />
      <div className={cn("absolute top-0 right-0 h-4 w-4 border-t-2 border-r-2", isComplete ? "border-xp-bar" : "border-muted-foreground/30")} />
      <div className={cn("absolute bottom-0 left-0 h-4 w-4 border-b-2 border-l-2", isComplete ? "border-xp-bar" : "border-muted-foreground/30")} />
      <div className={cn("absolute right-0 bottom-0 h-4 w-4 border-r-2 border-b-2", isComplete ? "border-xp-bar" : "border-muted-foreground/30")} />

      <div className="relative flex flex-col items-center justify-center gap-4 py-4 text-center md:flex-row md:justify-between md:py-2 md:text-left">
        {/* Date Section */}
        <div className="flex items-center gap-3">
          <div className={cn(
            "flex h-12 w-12 items-center justify-center rounded-xl",
            isComplete ? "bg-xp-bar/20 text-xp-bar" : "bg-secondary text-muted-foreground"
          )}>
            {isComplete ? <CheckCircle2 className="h-6 w-6" /> : <Clock className="h-6 w-6" />}
          </div>
          <div>
            <h3 className="font-bold text-foreground">{formatDate(date)}</h3>
            <p className="text-sm text-muted-foreground">
              {isToday() ? "Today's Progress" : "Past Progress"}
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="flex items-center gap-6">
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-xl font-bold text-foreground">
              <Target className="h-5 w-5 text-primary" />
              {completedQuests}/{totalQuests}
            </div>
            <p className="text-xs text-muted-foreground">Quests</p>
          </div>

          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-xl font-bold text-xp-bar">
              <Sparkles className="h-5 w-5" />
              +{xpEarned}
            </div>
            <p className="text-xs text-muted-foreground">XP Earned</p>
          </div>

          {/* Circular Progress */}
          <div className="relative h-16 w-16">
            <svg className="h-16 w-16 -rotate-90 transform">
              <circle
                cx="32"
                cy="32"
                r="28"
                className="fill-none stroke-secondary stroke-[4]"
              />
              <circle
                cx="32"
                cy="32"
                r="28"
                className={cn(
                  "fill-none stroke-[4] transition-all duration-1000",
                  isComplete ? "stroke-xp-bar" : "stroke-primary"
                )}
                strokeDasharray={`${2 * Math.PI * 28}`}
                strokeDashoffset={`${2 * Math.PI * 28 * (1 - percentage / 100)}`}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className={cn(
                "text-sm font-bold",
                isComplete ? "text-xp-bar" : "text-foreground"
              )}>
                {percentage}%
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Completion Message */}
      {isComplete && (
        <div className="relative mt-2 flex items-center justify-center gap-2 rounded-xl bg-xp-bar/20 py-2 text-sm font-medium text-xp-bar">
          <Sparkles className="h-4 w-4" />
          All quests completed! You&apos;re amazing!
          <Sparkles className="h-4 w-4" />
        </div>
      )}
    </div>
  )
}
