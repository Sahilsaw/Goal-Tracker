"use client"

import { ChevronLeft, ChevronRight, Flame, Star } from "lucide-react"
import { cn } from "@/lib/utils"

interface QuestCalendarProps {
  currentDate: Date
  selectedDate: Date
  onSelectDate: (date: Date) => void
  onNavigateMonth: (direction: "prev" | "next") => void
  completedDays: Set<string>
}

export function QuestCalendar({
  currentDate,
  selectedDate,
  onSelectDate,
  onNavigateMonth,
  completedDays,
}: QuestCalendarProps) {
  const today = new Date()
  const year = currentDate.getFullYear()
  const month = currentDate.getMonth()

  const firstDayOfMonth = new Date(year, month, 1)
  const lastDayOfMonth = new Date(year, month + 1, 0)
  const startingDayOfWeek = firstDayOfMonth.getDay()
  const daysInMonth = lastDayOfMonth.getDate()

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ]

  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

  const days: (number | null)[] = []
  for (let i = 0; i < startingDayOfWeek; i++) {
    days.push(null)
  }
  for (let i = 1; i <= daysInMonth; i++) {
    days.push(i)
  }

  const isToday = (day: number) =>
    day === today.getDate() && month === today.getMonth() && year === today.getFullYear()

  const isSelected = (day: number) =>
    day === selectedDate.getDate() && month === selectedDate.getMonth() && year === selectedDate.getFullYear()

  const isCompleted = (day: number) => {
    const dateKey = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`
    return completedDays.has(dateKey)
  }

  const goToToday = () => {
    onSelectDate(new Date())
  }

  return (
    <div className="relative overflow-hidden rounded-2xl border-2 border-mana-bar/30 bg-card">
      {/* Decorative corners */}
      <div className="absolute top-0 left-0 h-4 w-4 border-t-2 border-l-2 border-mana-bar" />
      <div className="absolute top-0 right-0 h-4 w-4 border-t-2 border-r-2 border-mana-bar" />
      <div className="absolute bottom-0 left-0 h-4 w-4 border-b-2 border-l-2 border-mana-bar" />
      <div className="absolute right-0 bottom-0 h-4 w-4 border-r-2 border-b-2 border-mana-bar" />

      {/* Header */}
      <div className="flex items-center justify-between border-b border-border bg-mana-bar/10 p-4">
        <button
          type="button"
          onClick={() => onNavigateMonth("prev")}
          className="flex h-8 w-8 items-center justify-center rounded-lg border border-border bg-secondary/50 text-foreground transition-colors hover:bg-secondary"
        >
          <ChevronLeft className="h-4 w-4" />
        </button>

        <div className="flex items-center gap-3">
          <h3 className="text-lg font-bold text-foreground">
            {monthNames[month]} {year}
          </h3>
          <button
            type="button"
            onClick={goToToday}
            className="rounded-full bg-mana-bar/20 px-3 py-1 text-xs font-medium text-mana-bar transition-colors hover:bg-mana-bar/30"
          >
            Today
          </button>
        </div>

        <button
          type="button"
          onClick={() => onNavigateMonth("next")}
          className="flex h-8 w-8 items-center justify-center rounded-lg border border-border bg-secondary/50 text-foreground transition-colors hover:bg-secondary"
        >
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>

      {/* Day Names */}
      <div className="grid grid-cols-7 border-b border-border bg-secondary/30">
        {dayNames.map((day) => (
          <div key={day} className="py-2 text-center text-xs font-medium text-muted-foreground">
            {day}
          </div>
        ))}
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-1 p-3">
        {days.map((day, index) => (
          <button
            key={`day-${index}`}
            type="button"
            onClick={() => day && onSelectDate(new Date(year, month, day))}
            disabled={!day}
            className={cn(
              "relative flex h-10 w-full items-center justify-center rounded-lg text-sm font-medium transition-all",
              !day && "invisible",
              day && "hover:bg-mana-bar/20",
              isSelected(day!) && "bg-mana-bar text-primary-foreground shadow-lg shadow-mana-bar/30",
              isToday(day!) && !isSelected(day!) && "border-2 border-mana-bar text-mana-bar",
              isCompleted(day!) && !isSelected(day!) && "bg-xp-bar/20 text-xp-bar"
            )}
          >
            {day}
            {day && isCompleted(day) && (
              <Star className="absolute -top-1 -right-1 h-3 w-3 fill-gold text-gold" />
            )}
          </button>
        ))}
      </div>

      {/* Legend */}
      <div className="flex items-center justify-center gap-4 border-t border-border p-3">
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <div className="h-3 w-3 rounded border-2 border-mana-bar" />
          <span>Today</span>
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <div className="h-3 w-3 rounded bg-xp-bar/20" />
          <Star className="h-3 w-3 text-gold" />
          <span>Completed</span>
        </div>
      </div>
    </div>
  )
}
