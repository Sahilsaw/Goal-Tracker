"use client"

import { useState, useEffect, useCallback } from "react"
import { Play, Code, Terminal, Sparkles } from "lucide-react"
import { PlayerCard } from "@/components/goal-tracker/player-card"
import { QuestCard, type Quest } from "@/components/goal-tracker/quest-card"
import { QuestCalendar } from "@/components/goal-tracker/quest-calendar"
import { Achievements } from "@/components/goal-tracker/achievements"
import { DailySummary } from "@/components/goal-tracker/daily-summary"

interface DayData {
  videoQuests: Quest[]
  dsaQuests: Quest[]
  devQuests: Quest[]
}

function generateId(): string {
  return Math.random().toString(36).substring(2, 9)
}

function getDateKey(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`
}

function getTodayKey(): string {
  return getDateKey(new Date())
}

// Calculate XP required for each level (increases with level)
function getXpForLevel(level: number): number {
  return 100 + (level - 1) * 50
}

export default function GoalTrackerPage() {
  const [selectedDate, setSelectedDate] = useState(new Date())
  const [currentMonth, setCurrentMonth] = useState(new Date())
  const [allDaysData, setAllDaysData] = useState<Record<string, DayData>>({})
  const [completedDays, setCompletedDays] = useState<Set<string>>(new Set())
  const [level, setLevel] = useState(1)
  const [currentXp, setCurrentXp] = useState(0)
  const [totalXp, setTotalXp] = useState(0)
  const [streak, setStreak] = useState(0)
  const [bestStreak, setBestStreak] = useState(0)
  const [totalQuestsCompleted, setTotalQuestsCompleted] = useState(0)
  const [isLoaded, setIsLoaded] = useState(false)

  // Load saved data from localStorage
  useEffect(() => {
    const savedData = localStorage.getItem("codequest-data")
    if (savedData) {
      const parsed = JSON.parse(savedData)
      setAllDaysData(parsed.allDaysData || {})
      setCompletedDays(new Set(parsed.completedDays || []))
      setLevel(parsed.level || 1)
      setCurrentXp(parsed.currentXp || 0)
      setTotalXp(parsed.totalXp || 0)
      setStreak(parsed.streak || 0)
      setBestStreak(parsed.bestStreak || 0)
      setTotalQuestsCompleted(parsed.totalQuestsCompleted || 0)
    }
    setIsLoaded(true)
  }, [])

  // Save data to localStorage
  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(
        "codequest-data",
        JSON.stringify({
          allDaysData,
          completedDays: Array.from(completedDays),
          level,
          currentXp,
          totalXp,
          streak,
          bestStreak,
          totalQuestsCompleted,
        })
      )
    }
  }, [allDaysData, completedDays, level, currentXp, totalXp, streak, bestStreak, totalQuestsCompleted, isLoaded])

  // Get or create data for selected date
  const dateKey = getDateKey(selectedDate)
  const dayData: DayData = allDaysData[dateKey] || {
    videoQuests: [],
    dsaQuests: [],
    devQuests: [],
  }

  const updateDayData = useCallback((newData: DayData) => {
    setAllDaysData((prev) => ({
      ...prev,
      [dateKey]: newData,
    }))
  }, [dateKey])

  // Calculate if all quests for a day are completed
  const calculateDayCompletion = useCallback((data: DayData) => {
    const allQuests = [...data.videoQuests, ...data.dsaQuests, ...data.devQuests]
    return allQuests.length > 0 && allQuests.every((q) => q.completed)
  }, [])

  // Add XP and handle level up
  const addXp = useCallback((amount: number) => {
    setCurrentXp((prev) => {
      let newXp = prev + amount
      let newLevel = level
      let xpForCurrentLevel = getXpForLevel(newLevel)

      while (newXp >= xpForCurrentLevel) {
        newXp -= xpForCurrentLevel
        newLevel++
        xpForCurrentLevel = getXpForLevel(newLevel)
      }

      if (newLevel !== level) {
        setLevel(newLevel)
      }

      return newXp
    })
    setTotalXp((prev) => prev + amount)
  }, [level])

  // Update streak calculation
  const updateStreak = useCallback(() => {
    const today = new Date()
    let currentStreak = 0
    const checkDate = new Date(today)

    // Check consecutive days backwards from today
    while (true) {
      const key = getDateKey(checkDate)
      if (completedDays.has(key)) {
        currentStreak++
        checkDate.setDate(checkDate.getDate() - 1)
      } else {
        break
      }
    }

    setStreak(currentStreak)
    if (currentStreak > bestStreak) {
      setBestStreak(currentStreak)
    }
  }, [completedDays, bestStreak])

  // Handler functions for quests
  const handleAddQuest = (type: "video" | "dsa" | "dev") => (title: string) => {
    const newQuest: Quest = {
      id: generateId(),
      title,
      completed: false,
      xpReward: type === "video" ? 10 : type === "dsa" ? 25 : 15,
    }

    const newData = { ...dayData }
    if (type === "video") newData.videoQuests = [...newData.videoQuests, newQuest]
    if (type === "dsa") newData.dsaQuests = [...newData.dsaQuests, newQuest]
    if (type === "dev") newData.devQuests = [...newData.devQuests, newQuest]
    updateDayData(newData)
  }

  const handleToggleQuest = (type: "video" | "dsa" | "dev") => (id: string) => {
    const newData = { ...dayData }
    const questList = type === "video" ? "videoQuests" : type === "dsa" ? "dsaQuests" : "devQuests"
    
    newData[questList] = newData[questList].map((q) => {
      if (q.id === id) {
        const wasCompleted = q.completed
        if (!wasCompleted) {
          // Quest is being completed
          addXp(q.xpReward)
          setTotalQuestsCompleted((prev) => prev + 1)
        }
        return { ...q, completed: !q.completed }
      }
      return q
    })
    
    updateDayData(newData)

    // Check if day is now complete
    const isComplete = calculateDayCompletion(newData)
    if (isComplete && !completedDays.has(dateKey)) {
      setCompletedDays((prev) => new Set([...prev, dateKey]))
      // Update streak if this is today
      if (dateKey === getTodayKey()) {
        updateStreak()
      }
    } else if (!isComplete && completedDays.has(dateKey)) {
      setCompletedDays((prev) => {
        const newSet = new Set(prev)
        newSet.delete(dateKey)
        return newSet
      })
      updateStreak()
    }
  }

  const handleDeleteQuest = (type: "video" | "dsa" | "dev") => (id: string) => {
    const newData = { ...dayData }
    const questList = type === "video" ? "videoQuests" : type === "dsa" ? "dsaQuests" : "devQuests"
    newData[questList] = newData[questList].filter((q) => q.id !== id)
    updateDayData(newData)
  }

  const handleNavigateMonth = (direction: "prev" | "next") => {
    setCurrentMonth((prev) => {
      const newDate = new Date(prev)
      if (direction === "prev") {
        newDate.setMonth(prev.getMonth() - 1)
      } else {
        newDate.setMonth(prev.getMonth() + 1)
      }
      return newDate
    })
  }

  // Calculate daily stats
  const allQuests = [...dayData.videoQuests, ...dayData.dsaQuests, ...dayData.devQuests]
  const completedQuests = allQuests.filter((q) => q.completed).length
  const xpEarnedToday = allQuests.reduce((acc, q) => (q.completed ? acc + q.xpReward : acc), 0)

  if (!isLoaded) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent" />
          <p className="text-lg font-medium text-muted-foreground">Loading your adventure...</p>
        </div>
      </div>
    )
  }

  return (
    <main className="min-h-screen bg-background">
      {/* Animated background pattern */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-1/2 -left-1/2 h-full w-full bg-[radial-gradient(circle,rgba(139,92,246,0.1)_0%,transparent_50%)] animate-pulse" />
        <div className="absolute -bottom-1/2 -right-1/2 h-full w-full bg-[radial-gradient(circle,rgba(236,72,153,0.08)_0%,transparent_50%)]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 py-6 md:py-10">
        {/* Header */}
        <header className="mb-8 text-center">
          <div className="mb-2 flex items-center justify-center gap-2">
            <Sparkles className="h-6 w-6 text-primary" />
            <h1 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
              Code<span className="text-primary">Quest</span>
            </h1>
            <Sparkles className="h-6 w-6 text-primary" />
          </div>
          <p className="text-muted-foreground">Level up your coding skills, one quest at a time!</p>
        </header>

        {/* Main Grid */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Left Column - Player Card & Calendar */}
          <div className="space-y-6 lg:col-span-1">
            <PlayerCard
              level={level}
              xp={currentXp}
              maxXp={getXpForLevel(level)}
              streak={streak}
              bestStreak={bestStreak}
              totalXp={totalXp}
            />
            
            <QuestCalendar
              currentDate={currentMonth}
              selectedDate={selectedDate}
              onSelectDate={setSelectedDate}
              onNavigateMonth={handleNavigateMonth}
              completedDays={completedDays}
            />
          </div>

          {/* Right Column - Daily Summary & Quests */}
          <div className="space-y-6 lg:col-span-2">
            <DailySummary
              date={selectedDate}
              completedQuests={completedQuests}
              totalQuests={allQuests.length}
              xpEarned={xpEarnedToday}
            />

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <QuestCard
                title="Videos"
                icon={<Play className="h-5 w-5" />}
                quests={dayData.videoQuests}
                onAddQuest={handleAddQuest("video")}
                onToggleQuest={handleToggleQuest("video")}
                onDeleteQuest={handleDeleteQuest("video")}
                color="video"
              />

              <QuestCard
                title="DSA Questions"
                icon={<Code className="h-5 w-5" />}
                quests={dayData.dsaQuests}
                onAddQuest={handleAddQuest("dsa")}
                onToggleQuest={handleToggleQuest("dsa")}
                onDeleteQuest={handleDeleteQuest("dsa")}
                color="dsa"
              />

              <QuestCard
                title="Dev Tasks"
                icon={<Terminal className="h-5 w-5" />}
                quests={dayData.devQuests}
                onAddQuest={handleAddQuest("dev")}
                onToggleQuest={handleToggleQuest("dev")}
                onDeleteQuest={handleDeleteQuest("dev")}
                color="dev"
              />
            </div>

            <Achievements
              totalXp={totalXp}
              streak={streak}
              bestStreak={bestStreak}
              totalQuests={totalQuestsCompleted}
            />
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-12 text-center text-sm text-muted-foreground">
          <p>Keep grinding, future code master! Your consistency today shapes your skills tomorrow.</p>
        </footer>
      </div>
    </main>
  )
}
